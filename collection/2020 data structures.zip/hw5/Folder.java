// Vincent Chi, 112811026, vincent.chi@stonybrook.edu, hw#5, R30 Section 1

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

/**
 * Folder
 * The Folder class holds emails.
 */
public class Folder implements Serializable{
    private ArrayList<Email> emails = new ArrayList<Email>(); //to hold emails
    private String name; //name of folder
    private String currentSortingMethod; //currentSortMethod

    private static final long serialVersionUID = 1L;


    /**
     * Constructor for ItemInfo
     */
    public Folder(){}

    //getters and setters
    public ArrayList<Email> getEmails() {
        return emails;
    }

    public void setSortingMethod(String toSet) {
        currentSortingMethod = toSet;
    }

    public String getName() {
        return name;
    }

    public void setName(String toSet) {
        name = toSet;
    }

    /**
     * Adds an email into the collection
     * @param email to add
     */
    public void addEmail(Email email) {
        emails.add(email);
    }

    /**
     * Removes an email from the collection
     * @param index of email to remove
     */
    public Email removeEmail(int index) {
        return emails.remove(index);
    }

    /**
     * Sorts email by ascending subject order.
     */
    public void sortBySubjectAscending() {
        Collections.sort(emails, new Comparator<Email>() {
            @Override
            public int compare(Email e1, Email e2) {
                return e1.getSubject().compareTo(e2.getSubject());
            }
        });
    }

    /**
     * Sorts email by descending subject order.
     */
    public void sortBySubjectDescending() {
        Collections.sort(emails, new Comparator<Email>() {
            @Override
            public int compare(Email e1, Email e2) {
                return e2.getSubject().compareTo(e1.getSubject());
            }
        });
    }

    /**
     * Sorts email by ascending date order.
     */
    public void sortByDateAscending() {
        Collections.sort(emails, new Comparator<Email>() {
            @Override
            public int compare(Email e1, Email e2) {
                return e1.getTimeStamp().compareTo(e2.getTimeStamp());
            }
        });
    }

    /**
     * Sorts email by descending date order.
     */
    public void sortByDateDescending() {
        Collections.sort(emails, new Comparator<Email>() {
            @Override
            public int compare(Email e1, Email e2) {
                return e2.getTimeStamp().compareTo(e1.getTimeStamp());
            }
        });
    }

    /**
     * ToString formats this folder into String for UI
     * @return formatted String.
     */
    public String toString() {
        if (currentSortingMethod == null) {
            currentSortingMethod = "Not sorted";
        }
        String toReturn = currentSortingMethod +
                          "\nIndex |        Time       | Subject\n" +
                          "-----------------------------------\n";
        int index = 1;
        if (emails == null) {

        }
        else {
            for (Email e: emails) {
                toReturn = toReturn + "\n  " + Integer.valueOf(index) + 
                                      "   |" + e;
                index++;
            }
        }
        return toReturn;
    }
}