// Vincent Chi, 112811026, vincent.chi@stonybrook.edu, hw#5, R30 Section 1


import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Scanner;

public class Mailbox implements Serializable {
    /**
     * To fulfill editor requirement.
     */
    // private static final long serialVersionUID = 1L;

    private Folder inbox = new Folder();
    private Folder trash;
    private ArrayList<Folder> folders = new ArrayList<Folder>();
    public static Mailbox mailbox;

    //getters and setters
    public ArrayList<Folder> getFolders() {
        return folders;
    }

    public Folder getInbox() {
        return inbox;
    }

    public Folder getTrash() {
        return trash;
    }

    public void emptyTrash() {
        trash = new Folder();
    }

    public void setFolders(ArrayList<Folder> folders) {
        this.folders = folders;
    }

    public void setInbox(Folder toSet) {
        inbox = toSet;
    }

    /**
     * Adds a folder to this mailbox
     * @param folder folder to add.
     */
    public void addFolder(Folder folder) {
        // System.out.println(folders);
        folders.add(folder);
    }

    /**
     * Deletes a folder from this mailbox
     * @param name of folder to delete.
     */
    public void deleteFolder(String name) {
        folders.removeIf(folder -> folder.getName().equals(name));
    }

    /**
     * requests integer input from user
     * @param scan the input
     * @param prompt the request
     * @return int
     */
    private static int reqInt(Scanner scan, String prompt){
        System.out.print(prompt);
        int answer = scan.nextInt();
        return answer;
    }
    
    /**
     * requests String input from user
     * @param scan the input
     * @param prompt the request
     * @return String
     */
    private static String reqInput(Scanner scan, String prompt){
        System.out.print(prompt);
        String answer = scan.next();
        return answer;
    }

    /**
     * requests String input from user
     * @param scan the input
     * @param prompt the request
     * @return String
     */
    private static String lineInput(Scanner scan, String prompt){
        System.out.print(prompt);
        String answer = scan.next();
        scan.nextLine();
        return answer;
    }

    /**
     * Composes an email to inbox folder.
     */
    public void composeEmail() {
        Scanner scan = new Scanner(System.in);
        System.out.println("Composing new email...");
        String to = reqInput(scan, "Enter recipient (To): ");
        String cc = lineInput(scan, "Enter carbon copy recipients (CC): ");
        String bcc = lineInput(scan, "Enter blind carbon copy recipients (BCC): ");
        String subject = lineInput(scan, "Enter subject line: ");
        String body = lineInput(scan, "Enter body: ");
        Email toInbox = new Email(to, cc, bcc, subject, body);
        inbox.addEmail(toInbox);
    }

    /**
     * Called on after delete to add to trash.
     * @param email to add to trash (or email that was deleted).
     */
    public void deleteEmail(Email email) {
        trash.addEmail(email);
    }

    /**
     * Clears trash
     */
    public void clearTrash() {
        trash = new Folder();
    }

    /**
     * Moves specified email to a target folder.
     * @param email to move.
     * @param target folder to move email to.
     */
    public void moveEmail(Email email, Folder target) {
        if (target == trash) {
            trash.addEmail(email);
        }
        else if (folders.contains(target)) {
            target.addEmail(email);
        }
        else {
            inbox.addEmail(email);
        }
    }

    /**
     * Gets specified folder by name
     * @param name of folder to return.
     */
    public Folder getFolder(String name) {
        if (name.equalsIgnoreCase("inbox")) {
            return inbox;
        } else if (name.equalsIgnoreCase("trash")) {
            return trash;
        }
        for (Folder folder : folders) {
            if (folder.getName().equalsIgnoreCase(name)) {
                return folder;
            }
        }
        return null;
    }

    public static void main(String[] args) throws IllegalArgumentException,
                                                  IOException,
                                                  ClassNotFoundException {
        Scanner scan = new Scanner(System.in);
        System.out.println("\n Homework 5 \nSPECIALNOTES:\n"
        + "If it ever gets stuck just press Enter again.\n"
        + "You will have to actively VIEW the folder to see changes sometimes"
        + "\n sorts will work only sometimes.");
        String fileName = "mailbox.obj";
        File file = new File(fileName);
        // if (file.isFile() && file.canRead()) {
        //     ObjectInputStream InputStream = new ObjectInputStream(
        //         new FileInputStream(file));
        //         mailbox = (Mailbox) InputStream.readObject();
        //         InputStream.close();
        //     }
        // else {
            mailbox = new Mailbox();
            mailbox.setInbox(new Folder());
            mailbox.emptyTrash();
        //     ObjectOutputStream OutputStream = new ObjectOutputStream(
        //                                       new FileOutputStream(
        //                                       "mailbox.obj", true));
        //     OutputStream.writeObject(mailbox);
        //     OutputStream.close();
        // }


        while (true) {
            // for (Folder debug : mailbox.getFolders()) {
            //     System.out.println(debug.getName());
            // }//debug

            System.out.println("\nA - Add folder\n"
            + "R - Remove folder\n"
            + "C - Compose email\n"
            + "F - Open folder\n"
            + "I - Open Inbox\n"
            + "T - Open Trash\n"
            + "E - Empty Trash\n"
            + "Q - Quit (And Save)\n");

            System.out.print("Enter a user option: ");
            String input = scan.next();
            System.out.println();

            if (input.equalsIgnoreCase("A")){
                String folderName = reqInput(scan, "Enter folder name: ");
                Folder folderToAdd = new Folder();
                folderToAdd.setName(folderName);
                //System.out.println(mailbox.getFolders()); //Test
                mailbox.addFolder(folderToAdd);
            } else if (input.equalsIgnoreCase("R")){ 
                String folderName = reqInput(scan, "Enter folder name: ");
                mailbox.deleteFolder(folderName);
            
            } else if (input.equalsIgnoreCase("C")){ 
                // System.out.println(mailbox.getInbox().getEmails());
                mailbox.composeEmail();
                System.out.println("Email successfully added to Inbox.");
            
            } else if (input.equalsIgnoreCase("F")){ 
                String folderName = reqInput(scan, "Enter folder name: ");
                Folder toView = mailbox.getFolder(folderName);
                if (toView == null) {
                    System.out.println("Folder does not exist!");
                }
                else {
                    System.out.println(toView);
                    Folder toTraverse = mailbox.getInbox();
                System.out.println(toTraverse);
                while (true) {
        
                    System.out.println("\nM - Move email\n"
                    + "D - Delete email\n"
                    + "V - View email contents\n"
                    + "SA - Sort by subject ascending\n"
                    + "SD - Sort by subject descending\n"
                    + "DA - Sort by date ascending\n"
                    + "DD - Sort by date descending\n"
                    + "R - Return to main menu\n");
        
                    System.out.print("Enter a user option: ");
                    String input2 = scan.next();
                    System.out.println();
        
                    if (input2.equalsIgnoreCase("M")){
                        int emailIndex = reqInt(scan,
                                    "Enter the index of the email to move: ")-1;
                        System.out.println("Folders:\nInbox\nTrash");
                        for (Folder e: mailbox.folders) {
                            System.out.println(e.getName());
                        }
                        Email toMove = toTraverse.removeEmail(emailIndex);
                        String toMoveTo = reqInput(scan,
                                    "Select a folder to move + \"" +
                                    toMove.getSubject() + "\" to: ");
                        toTraverse = mailbox.getFolder(toMoveTo);
                        toTraverse.addEmail(toMove);
                        System.out.println("Moved!");
                        } else if (input2.equalsIgnoreCase("D")){ 
                            int removeIndex = reqInt(scan, "Enter email index: ")-1;
                            toTraverse.removeEmail(removeIndex);
                            System.out.println("Removed!");
                        
                        } else if (input2.equalsIgnoreCase("V")){ 
                            System.out.println(toTraverse);
                        
                        } else if (input2.equalsIgnoreCase("SA")){ 
                            toTraverse.sortBySubjectAscending();
                            toTraverse.setSortingMethod("Ascending by Subject");
                            System.out.println("Sorted!");
                        
                        } else if (input2.equalsIgnoreCase("SD")){ 
                            toTraverse.sortBySubjectDescending();
                            toTraverse.setSortingMethod("Descending by Subject");
                            System.out.println("Sorted!");
                            
                        } else if (input2.equalsIgnoreCase("DA")){ 
                            toTraverse.sortByDateAscending();
                            toTraverse.setSortingMethod("Ascending by Date");
                            System.out.println("Sorted!");
                        
                        } else if (input2.equalsIgnoreCase("DD")){ 
                            toTraverse.sortByDateDescending();
                            toTraverse.setSortingMethod("Descending by Date");
                            System.out.println("Sorted!");
                        
                        } else if (input2.equalsIgnoreCase("R")){ 
                            break;
            
                        } else {
                            System.out.println("Please input a valid option.");
                        }
                    }
                }
            
            } else if (input.equalsIgnoreCase("I")){ 
                Folder toTraverse = mailbox.getInbox();
                System.out.println(toTraverse);
                while (true) {
        
                    System.out.println("\nM - Move email\n"
                    + "D - Delete email\n"
                    + "V - View email contents\n"
                    + "SA - Sort by subject ascending\n"
                    + "SD - Sort by subject descending\n"
                    + "DA - Sort by date ascending\n"
                    + "DD - Sort by date descending\n"
                    + "R - Return to main menu\n");
        
                    System.out.print("Enter a user option: ");
                    String input2 = scan.next();
                    System.out.println();
        
                    if (input2.equalsIgnoreCase("M")){
                        int emailIndex = reqInt(scan,
                                    "Enter the index of the email to move: ")-1;
                        System.out.println("Folders:\nInbox\nTrash");
                        for (Folder e: mailbox.folders) {
                            System.out.println(e.getName());
                        }
                        Email toMove = toTraverse.removeEmail(emailIndex);
                        String toMoveTo = reqInput(scan,
                                    "Select a folder to move + \"" +
                                    toMove.getSubject() + "\" to: ");
                        toTraverse = mailbox.getFolder(toMoveTo);
                        toTraverse.addEmail(toMove);
                        System.out.println("Moved!");
                    } else if (input2.equalsIgnoreCase("D")){ 
                        int removeIndex = reqInt(scan, "Enter email index: ")-1;
                        toTraverse.removeEmail(removeIndex);
                        System.out.println("Removed!");
                    
                    } else if (input2.equalsIgnoreCase("V")){ 
                        System.out.println(toTraverse);
                    
                    } else if (input2.equalsIgnoreCase("SA")){ 
                        toTraverse.sortBySubjectAscending();
                        toTraverse.setSortingMethod("Ascending by Subject");
                        System.out.println("Sorted!");
                    
                    } else if (input2.equalsIgnoreCase("SD")){ 
                        toTraverse.sortBySubjectDescending();
                        toTraverse.setSortingMethod("Descending by Subject");
                        System.out.println("Sorted!");
                        
                    } else if (input2.equalsIgnoreCase("DA")){ 
                        toTraverse.sortByDateAscending();
                        toTraverse.setSortingMethod("Ascending by Date");
                        System.out.println("Sorted!");
                    
                    } else if (input2.equalsIgnoreCase("DD")){ 
                        toTraverse.sortByDateDescending();
                        toTraverse.setSortingMethod("Descending by Date");
                        System.out.println("Sorted!");
                    
                    } else if (input2.equalsIgnoreCase("R")){ 
                        break;
        
                    } else {
                        System.out.println("Please input a valid option.");
                    }
                }
            
            } else if (input.equalsIgnoreCase("T")){ 
                Folder toTraverse = mailbox.getTrash();
                // System.out.println(toTraverse);
                while (true) {
        
                    System.out.println("\nM - Move email\n"
                    + "D - Delete email\n"
                    + "V - View email contents\n"
                    + "SA - Sort by subject ascending\n"
                    + "SD - Sort by subject descending\n"
                    + "DA - Sort by date ascending\n"
                    + "DD - Sort by date descending\n"
                    + "R - Return to main menu\n");
        
                    System.out.print("Enter a user option: ");
                    String input2 = scan.next();
                    System.out.println();
        
                    if (input2.equalsIgnoreCase("M")){
                        int emailIndex = reqInt(scan,
                                    "Enter the index of the email to move: ")-1;
                        System.out.println("Folders:\nInbox\nTrash");
                        for (Folder e: mailbox.folders) {
                            System.out.println(e.getName());
                        }
                        Email toMove = toTraverse.removeEmail(emailIndex);
                        String toMoveTo = reqInput(scan,
                                    "Select a folder to move + \"" +
                                    toMove.getSubject() + "\" to: ");
                        toTraverse = mailbox.getFolder(toMoveTo);
                        toTraverse.addEmail(toMove);
                        System.out.println("Moved!");
                    } else if (input2.equalsIgnoreCase("D")){ 
                        int removeIndex = reqInt(scan, "Enter email index: ")-1;
                        toTraverse.removeEmail(removeIndex);
                        System.out.println("Removed!");
                    
                    } else if (input2.equalsIgnoreCase("V")){ 
                        System.out.println(toTraverse);
                    
                    } else if (input2.equalsIgnoreCase("SA")){ 
                        toTraverse.sortBySubjectAscending();
                        toTraverse.setSortingMethod("Ascending by Subject");
                        System.out.println("Sorted!");
                    
                    } else if (input2.equalsIgnoreCase("SD")){ 
                        toTraverse.sortBySubjectDescending();
                        toTraverse.setSortingMethod("Descending by Subject");
                        System.out.println("Sorted!");
                        
                    } else if (input2.equalsIgnoreCase("DA")){ 
                        toTraverse.sortByDateAscending();
                        toTraverse.setSortingMethod("Ascending by Date");
                        System.out.println("Sorted!");
                    
                    } else if (input2.equalsIgnoreCase("DD")){ 
                        toTraverse.sortByDateDescending();
                        toTraverse.setSortingMethod("Descending by Date");
                        System.out.println("Sorted!");
                    
                    } else if (input2.equalsIgnoreCase("R")){ 
                        break;
        
                    } else {
                        System.out.println("Please input a valid option.");
                    }
                }
            
            } else if (input.equalsIgnoreCase("E")){ 
                mailbox.emptyTrash();
                System.out.println("Trash has been cleared!");
            
            } else if (input.equalsIgnoreCase("Q")){
                ObjectOutputStream OutputStream = new ObjectOutputStream(
                                              new FileOutputStream(
                                              "mailbox.obj", true));
                OutputStream.writeObject(mailbox);
                OutputStream.close();
                break;

            } else {
                System.out.println("Please input a valid option.");
            }
        }
    }
}