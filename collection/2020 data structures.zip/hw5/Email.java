// Vincent Chi, 112811026, vincent.chi@stonybrook.edu, hw#5, R30 Section 1

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.GregorianCalendar;
import java.text.SimpleDateFormat;

/**
 * Email
 * The Email class holds all the information about emails.
 */
public class Email implements Serializable {
    private String to; // to who
    private String cc; // cc of email
    private String bcc; // bcc of email
    private String subject; //subject of email
    private String body; //body of email
    private GregorianCalendar timestamp; //timestamp of email
    private static final long serialVersionUID = 1L;


    /**
     * Constructor for ItemInfo
     */
    public Email() {

    }

    /**
     * Constructor for ItemInfo
     * @param toSetTo
     * @param toSetCC
     * @param toSetBCC
     * @param toSetSubject
     * @param toSetBody
     */
    public Email(String toSetTo,
                 String toSetCC,
                 String toSetBCC,
                 String toSetSubject,
                 String toSetBody) {
        ZoneId z = ZoneId.of("America/New_York") ;
        LocalDate ld = LocalDate.now();
        LocalTime lt = LocalTime.now();
        ZonedDateTime zdt =  ZonedDateTime.of(ld, lt, z);
        GregorianCalendar gc = GregorianCalendar.from(zdt);
        timestamp = gc;
        to = toSetTo;
        cc = toSetCC;
        bcc = toSetBCC;
        subject = toSetSubject;
        body = toSetBody;
    }

    //getters and setters
    public String getTo() {
        return to;
    }

    public String getCc() {
        return cc;
    }

    public String getBcc() {
        return bcc;
    }

    public String getSubject() {
        return subject;
    }

    public String getBody() {
        return body;
    }

    public GregorianCalendar getTimeStamp() {
        return timestamp;
    }

    public void setTo(String toSet) {
        to = toSet;
    }

    public void setCc(String toSet) {
        cc = toSet;
    }

    public void setBcc(String toSet) {
        bcc = toSet;
    }

    public void setSubject(String toSet) {
        subject = toSet;
    }

    public void setBody(String toSet) {
        body = toSet;
    }

    public void setTimeStamp(GregorianCalendar toSet) {
        timestamp = toSet;
    }

    /**
     * This method pads strings so that they are aligned.
     * @param s the string that needs padding.
     * @param n the spaces needed to align.
     * @return the padded string.
     */
    public static String padRight(String s, int n) {
        return String.format("%-" + n + "s", s);
    }

    public String format(GregorianCalendar calendar) {
        SimpleDateFormat fmt = new SimpleDateFormat("dd-MMM-yyyy");
        SimpleDateFormat time = new SimpleDateFormat("h:mm a");
        fmt.setCalendar(calendar);
        time.setCalendar(calendar);
        String dateFormatted = fmt.format(calendar.getTime());
        String timeFormatted = time.format(calendar.getTime());


        return timeFormatted + " " + dateFormatted;
    }

    /**
     * ToString formats email as string for UI
     * @return the formatted String.
     */
    public String toString() {
        String toReturn = " " + padRight(format(timestamp), 17) + "| " +
                          subject + "\n";
        return toReturn;
    }
}