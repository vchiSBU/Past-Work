// Vincent Chi, 112811026, vincent.chi@stonybrook.edu, hw#2, R30 Section 1

/**
 * ItemInfo
 * The ItemInfo class holds all the information about items.
 */
public class ItemInfo {
    private String name; // the name of the item
    private double price; // the price of the item

    private String rfidTagNumber; // the rfidTagNumber of the item
    private String originalLoc; // the originalLoc of the item
    private String currentLoc; // the currentLoc of the item

    /**
     * Constructor for ItemInfo
     */
    public ItemInfo() {

    }

    /**
     * Constructor with params for ItemInfo
     * @param nameArg
     * @param rFidTagArg
     * @param priceArg
     * @param originalLocArg
     */
    public ItemInfo(String nameArg,
                    String rFidTagArg,
                    double priceArg,
                    String originalLocArg) {
        name = nameArg;
        price = priceArg;
        rfidTagNumber = rFidTagArg;
        originalLoc = originalLocArg;
        currentLoc = originalLocArg;
    }
    /**
     * getters and setters for price
     */
    public double getPrice() {
        return price;
    }
    public void setPrice(double priceSet) {
        price = priceSet;
    }
    /**
     * getters and setters for name
     */
    public String getName() {
        return name;
    }
    public void setName(String nameSet) {
        name = nameSet;
    }
    /**
     * getters and setters for rfidTagNumber
     */
    public String getrfidTagNumber() {
        return rfidTagNumber;
    }
    public void setrfidTagNumber(String tagSet) {
        rfidTagNumber = tagSet;
    }
    /**
     * getters and setters for OriginalLoc
     */
    public String getOriginalLoc() {
        return originalLoc;
    }
    public void setOriginalLoc(String locSet) {
        originalLoc = locSet;
    }
    /**
     * getters and setters for CurrentLoc
     */
    public String getCurrentLoc() {
        return currentLoc;
    }
    public void setCurrentLoc(String locSet) {
        currentLoc = locSet;
    }

    /**
     * This method pads strings so that they are aligned.
     * @param s the string that needs padding.
     * @param n the spaces needed to align.
     * @return the padded string.
     */
    public static String padRight(String s, int n) {
        return String.format("%-" + n + "s", s);
    }

    /**
     * This method creates a neatly displayed toString of this ItemInfo.
     */
    public String toString(){
        String stringToReturn;
        stringToReturn = padRight(this.name, 16) +
                         padRight(this.rfidTagNumber, 16) +
                         padRight(this.originalLoc, 16) +
                         padRight(this.currentLoc, 12) +
                         String.valueOf(this.price);
        return stringToReturn;
    }

}