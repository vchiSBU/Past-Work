// Vincent Chi, 112811026, vincent.chi@stonybrook.edu, hw#2, R30 Section 1

/**
 * ItemInfoNode
 * This is the Node class that holds Linkedlist references
 *     as well as information inside this particular node.
 */
public class ItemInfoNode {
    
    private ItemInfoNode prev; //previous node reference
    private ItemInfoNode next; //next node reference
    private ItemInfo thisNode; //this node's information

    /**
     * Constructor for ItemInfoNode
     */
    public ItemInfoNode(){

    }

    /**
     * getters and setters for info
     */
    public void setInfo(ItemInfo info) {
        thisNode = info;
    }
    public ItemInfo getInfo() {
        return thisNode;
    }
    /**
     * getters and setters for next
     */
    public void setNext(ItemInfoNode node) {
        next = node;
    }
    public ItemInfoNode getNext() {
        return next;
    }
    /**
     * getters and setters for prev
     */
    public void setPrev(ItemInfoNode node) {
        prev = node;
    }
    public ItemInfoNode getPrev() {
        return prev;
    }
    
}