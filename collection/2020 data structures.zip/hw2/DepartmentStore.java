// Vincent Chi, 112811026, vincent.chi@stonybrook.edu, hw#2, R30 Section 1

/**
 * DepartmentStore
 * The UI for this homework.
 */
import java.util.Scanner;

public class DepartmentStore {
    
    /**
     * requests string input from user
     * @param scan the input
     * @param prompt the request
     * @return input
     */
    private static String reqInput(Scanner scan, String prompt){
        System.out.print(prompt);
        String answer = scan.next();
        return answer;
    }
    /**
     * requests string input from user
     * @param scan the input
     * @param prompt the request
     * @return input
     */
    private static String lineInput(Scanner scan, String prompt){
        System.out.print(prompt);
        String answer = scan.nextLine();
        return answer;
    }

    /**
     * requests double input from user
     * @param scan the input
     * @param prompt the request
     * @return double
     */
    private static double reqInt(Scanner scan, String prompt){
        System.out.print(prompt);
        double answer = scan.nextDouble();
        return answer;
    }

    public static void main(String[] args) throws IllegalArgumentException{
        ItemList newlist = new ItemList();
        Scanner scan = new Scanner(System.in);
        System.out.println("\n Homework 2 \n Welcome!");

        while (true) {

            String menu = "\nC - Clean store\n"
            + "I - Insert an item into the list\n"
            + "L - List by location\n"
            + "M - Move an item in the store\n"
            + "O - Checkout\n"
            + "P - Print all items in store\n"
            + "R - Print by RFID tag number\n"
            + "U - Update inventory system\n"
            + "Q) Quit\n\n";
            System.out.println(menu);
            System.out.print("Please select an option: ");
            String input = scan.next();
            System.out.println();

            if (input.equalsIgnoreCase("I")){
                scan.nextLine();
                String name = lineInput(scan, "Enter the name: ");
                String RFID = reqInput(scan, "Enter the RFID: ");
                String ori = reqInput(scan, "Enter the original location: ");
                double price = reqInt(scan, "Enter the price: ");

                newlist.insertInfo(name, RFID, price, ori);
                System.out.println("Item successfully added!\n");

            } else if (input.equalsIgnoreCase("M")){ 
                String rfidTag = reqInput(scan, "Enter the RFID: ");
                String ori = reqInput(scan, "Enter the original location: ");
                String newloc = reqInput(scan, "Enter the new location: ");

                boolean moved = newlist.moveItem(rfidTag, ori, newloc);
                if (moved == true) {
                    System.out.println("Item successfully moved!\n");
                }
                else {
                    System.out.println("\nSorry! We could not move the item\n");
                }
            
            } else if (input.equalsIgnoreCase("L")){ 
                String loca = reqInput(scan, "Enter the location: ");

                newlist.printByLocation(loca);
            
            } else if (input.equalsIgnoreCase("P")){ 
                newlist.printAll();
            
            } else if (input.equalsIgnoreCase("O")){ 
                String cartNum = reqInput(scan, "Enter the cart number: ");

                double toPrint = newlist.checkOut(cartNum);
                System.out.println("The total cost for all merchandise in "
                                 + cartNum
                                 + " was $"
                                 + String.valueOf(toPrint));
            
            } else if (input.equalsIgnoreCase("C")){ 
                System.out.println("The following item(s) " +
                "have been moved back to their original locations:\n");
                newlist.cleanStore();
            
            } else if (input.equalsIgnoreCase("U")){ 
                System.out.println("The following item(s) " +
                "have removed from the system:\n");
                newlist.removeAllPurchased();
            
            } else if (input.equalsIgnoreCase("R")){ 
                String rfidTag = reqInput(scan, "Enter the RFID: ");
                newlist.printbyRFID(rfidTag);
            
            } else if (input.equalsIgnoreCase("Q")){
                System.out.println("\n Program terminated. \n");
                break;
            } else {
                System.out.println("\n Invalid command. \n");
            }

        }
    }
}