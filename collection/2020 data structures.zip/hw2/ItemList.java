// Vincent Chi, 112811026, vincent.chi@stonybrook.edu, hw#2, R30 Section 1

/**
 * ItemList
 * This is the Linked List class that holds ItemInfoNodes.
 */
public class ItemList {
    
    private ItemInfoNode head; //head of linked list
    private ItemInfoNode tail; //tail of linked list

    /**
     * Constructor for ItemList
     */
    public ItemList() {

    }

    /**
     * getters and setters for head
     */
    public ItemInfoNode getHead() {
        return head;
    }
    public void setHead(ItemInfoNode arg) {
        head = arg;
    }
    /**
     * getters and setters for tail
     */
    public ItemInfoNode getTail() {
        return head;
    }
    public void setTail(ItemInfoNode arg) {
        tail = arg;
    }
    
    /**
     * Inserts the info into the list in its correct position
     *     based on its rfidTagNumber.
     * @param name the name of the info.
     * @param rfidTag the rfidTag of the info.
     * @param price the price of the info.
     * @param initPosition the initPosition of the info.
     * O(N) as it goes through the entire list when it orders.
     */
    public void insertInfo(String name,
                           String rfidTag,
                           double price,
                           String initPosition) throws IllegalArgumentException{
        boolean isHex = rfidTag.matches("^[0-9a-fA-F]+$");
        if (rfidTag.length() == 9 || isHex) {
        }
        else {
            throw new IllegalArgumentException("Not an acceptable rfidTag.");
        }

        String first = initPosition.substring(0,1);
        if (initPosition.equalsIgnoreCase("out")) {
        }
        else if (first.equalsIgnoreCase("s")) {
            if (initPosition.length() == 6) {
                if (initPosition.substring(1,6).matches("-?\\d+")) {
                }
                else {
                    throw new IllegalArgumentException("Inproper destination.");
                }
            }
            else {
                throw new IllegalArgumentException("Inproper destination.");
            }
        }
        else if (first.equalsIgnoreCase("c")) {
            if (initPosition.length() == 4) {
                if (initPosition.substring(1,4).matches("-?\\d+")) {
                }
                else {
                    throw new IllegalArgumentException("Inproper destination.");
                }
            }
            else {
                throw new IllegalArgumentException("Inproper destination.");
            }
        }
        else {
            throw new IllegalArgumentException("Inproper destination.");
        }

        ItemInfo holder = new ItemInfo(name, rfidTag, price, initPosition);
        ItemInfoNode toPut = new ItemInfoNode();
        toPut.setInfo(holder);
        if (head == null) {
            head = toPut;
            tail = toPut;
        }
        else if (head.getNext() == null) {
            if (rfidTag.compareTo(head.getInfo().getrfidTagNumber()) <= 0) {
                toPut.setNext(head);
                head.setPrev(toPut);
                head = toPut;
                tail = toPut.getNext();
            }
            else {
                    head.setNext(toPut);
                    toPut.setPrev(head);
                    tail = toPut;
                }
        }
        else {
            if (rfidTag.compareTo(head.getInfo().getrfidTagNumber()) <= 0) {
                toPut.setNext(head);
                head.setPrev(toPut);
                head = toPut;
            }
            else {
                    ItemInfoNode cursor = head;
                    while (cursor.getNext() != null) {
                        if (rfidTag.compareTo(cursor.getInfo().
                                              getrfidTagNumber()) <= 0) {
                            ItemInfoNode temp = cursor.getPrev();
                            toPut.setNext(cursor);
                            cursor.setPrev(toPut);
                            temp.setNext(toPut);
                            toPut.setPrev(temp);
                            return;
                        }
                        else {
                            cursor = cursor.getNext();
                        }
                    }
                    if (rfidTag.compareTo(tail.getInfo().
                                          getrfidTagNumber()) <= 0) {
                        ItemInfoNode temp = tail.getPrev();
                        temp.setNext(toPut);
                        toPut.setPrev(temp);
                        toPut.setNext(tail);
                        tail.setPrev(toPut);
                    }
                    else {
                        tail.setNext(toPut);
                        toPut.setPrev(tail);
                        tail = toPut;
                    }
                }
        }
    } 

    /**
     * Removes all nodes in list that have current location listed as "out".
     *     then prints list of all items that have been removed in this fashion.
     * O(N) goes through the entire list (once) to remove all cases of out.
     */
    public void removeAllPurchased() {
        System.out.println(
            "\n The following item(s) have removed from the system: ");
        System.out.println(
        "\n                               Original        Current"+
        "\nItem Name         RFID         Location        Location     Price"+
        "\n---------       ---------     ---------        ---------   ------");
        int counter = 0;
        if (head == null) {
            System.out.println("It looks like there were "+
                               "no items marked to checkout.");
            return;
        }
        else {
            ItemInfoNode nodePtr = head;
            while (nodePtr.getNext() != null) {
                if (nodePtr.getInfo().getCurrentLoc().equalsIgnoreCase("out")) {
                    System.out.println(nodePtr.getInfo());
                    if (nodePtr == head) {
                        head = head.getNext();
                    }
                    else{
                        ItemInfoNode temp1 = nodePtr.getPrev();
                        ItemInfoNode temp2 = nodePtr.getNext();
                        temp1.setNext(temp2);
                        temp2.setPrev(temp1);
                    }
                    counter++;
                }
                nodePtr = nodePtr.getNext();
            }
            if (nodePtr == head) {
                if (nodePtr.getInfo().getCurrentLoc().equalsIgnoreCase("out")) {
                    System.out.println(nodePtr.getInfo());
                    head = null;
                    tail = null;
                    counter++;
                }
            }
            else {
                if (nodePtr.getInfo().getCurrentLoc().equalsIgnoreCase("out")) {
                    System.out.println(nodePtr.getInfo());
                    ItemInfoNode newTail = tail.getPrev();
                    newTail.setNext(null);
                    tail = newTail;
                    counter++;
                }
            }
            if (counter == 0) {
                System.out.println("It looks like there were "+
                                   "no items marked to checkout.");
            }
        }
    }

    /**
     * Moves an item with a given rfidTagNumber from a
     *     source location to a dest location.
     * @param rfidTag the rfidTag of the item.
     * @param source the initPosition of the item.
     * @param dest the resulting position of the item.
     * @return truth value for if there is the item in dest.
     * O(N) goes through linked list to find a single item.
     */
    public boolean moveItem(String rfidTag,
                            String source,
                            String dest) throws IllegalArgumentException {
        String first = dest.substring(0,1);
        if (dest.equalsIgnoreCase("out")) {
        }
        else if (first.equalsIgnoreCase("s")) {
            if (dest.length() == 6) {
                if (dest.substring(1,6).matches("-?\\d+")) {
                }
                else {
                    throw new IllegalArgumentException("Inproper destination.");
                }
            }
            else {
                throw new IllegalArgumentException("Inproper destination.");
            }
        }
        else if (first.equalsIgnoreCase("c")) {
            if (dest.length() == 4) {
                if (dest.substring(1,4).matches("-?\\d+")) {
                }
                else {
                    throw new IllegalArgumentException("Inproper destination.");
                }
            }
            else {
                throw new IllegalArgumentException("Inproper destination.");
            }
        }
        else {
            throw new IllegalArgumentException("Inproper destination.");
        }
        ItemInfoNode nodePtr = head;
        while (nodePtr != null) {
            if (nodePtr.getInfo().getCurrentLoc().equalsIgnoreCase(source) &&
                nodePtr.getInfo().getrfidTagNumber().equalsIgnoreCase(rfidTag)){
                nodePtr.getInfo().setCurrentLoc(dest);
                return true;
            }
            nodePtr = nodePtr.getNext();
        }
        return false;
    }

    /**
     * Prints a neatly formatted list of all items currently in the list.
     * O(N) needs to traverse through entire list to print.
     */
    public void printAll() {
        System.out.println(
        "\n                               Original        Current" +
        "\nItem Name         RFID         Location        Location     Price"+
        "\n---------       ---------     ---------        ---------   ------");
        ItemInfoNode nodePtr = head;
        while (nodePtr != null) {
            System.out.println(nodePtr.getInfo());
            nodePtr = nodePtr.getNext();
        }
    }

    /**
     * Prints a formatted list of all items in a specified current location. 
     * @param location the specified location of the desired list.
     * O(N) needs to traverse through entire list to print.
     */
    public void printByLocation(String location) {
        String first = location.substring(0,1);
        if (location.equalsIgnoreCase("out")) {
        }
        else if (first.equalsIgnoreCase("s")) {
            if (location.length() == 6) {
                if (location.substring(1,6).matches("-?\\d+")) {
                }
                else {
                    throw new IllegalArgumentException("Inproper location.");
                }
            }
            else {
                throw new IllegalArgumentException("Inproper location.");
            }
        }
        else if (first.equalsIgnoreCase("c")) {
            if (location.length() == 4) {
                if (location.substring(1,4).matches("-?\\d+")) {
                }
                else {
                    throw new IllegalArgumentException("Inproper location.");
                }
            }
            else {
                throw new IllegalArgumentException("Inproper location.");
            }
        }
        else {
            throw new IllegalArgumentException("Inproper location.");
        }
        System.out.println(
        "\n                               Original        Current" +
        "\nItem Name         RFID         Location        Location     Price"+
        "\n---------       ---------     ---------        ---------   ------");
        ItemInfoNode nodePtr = head;
        int counter = 0;
        while (nodePtr != null) {
            if(nodePtr.getInfo().getCurrentLoc().equalsIgnoreCase(location)) {
                System.out.println(nodePtr.getInfo());
                counter++;
            }
            nodePtr = nodePtr.getNext();
        }
        if (counter == 0) {
            System.out.println("It looks like there were "+
                               "no items that matched that location.");
        }
    }

    /**
     * Takes every item that is currently in the store and on the wrong shelf
     *     and places it back where it belongs (its original location)
     * O(N) needs to go through entire list to correct locations.
     */
    public void cleanStore() {
        System.out.println(
        "\n                               Original        Current" +
        "\nItem Name         RFID         Location        Location     Price" +
        "\n---------       ---------     ---------        ---------   ------");
        int counter = 0;
        ItemInfoNode nodePtr = head;
        while (nodePtr != null) {
            if(nodePtr.getInfo().getCurrentLoc().equalsIgnoreCase(
               nodePtr.getInfo().getOriginalLoc()) == false) {
                if (nodePtr.getInfo().getCurrentLoc().equalsIgnoreCase("out")) {
                }
                else if (nodePtr.getInfo().getCurrentLoc().
                         substring(0,1).equalsIgnoreCase("c")) {
                }
                else {
                    nodePtr.getInfo().setCurrentLoc(nodePtr.getInfo().
                                                    getOriginalLoc());
                    System.out.println(nodePtr.getInfo());
                    counter++;
                }
            }
            nodePtr = nodePtr.getNext();
        }
        if (counter == 0) {
            System.out.println("It looks like there wasn't anything to clean.");
        }
    }

    /**
     * Goes through a given cart and checks out each item
     *     (changes its location to "out")
     * @param cartNumber the cart to be checked out.
     * @return the total cost for the items that were in the cart.
     * O(N) goes through linked list to checkout every item in the cart.
     */
    public double checkOut(String cartNumber) throws IllegalArgumentException {
        System.out.println(
        "\n                               Original        Current" +
        "\nItem Name         RFID         Location        Location     Price" +
        "\n---------       ---------     ---------        ---------   ------");
        double totalPrice = 0;
        ItemInfoNode nodePtr = head;
        String first = cartNumber.substring(0,1);
        if (first.equalsIgnoreCase("c")) {
            if (cartNumber.length() == 4) {
                if (cartNumber.substring(1,4).matches("-?\\d+")) {
                }
                else {
                    throw new IllegalArgumentException("Inproper destination.");
                }
            }
            else {
                throw new IllegalArgumentException("Inproper destination.");
            }
        }
        while (nodePtr != null) {
            if(nodePtr.getInfo().getCurrentLoc().equalsIgnoreCase(cartNumber)) {
                nodePtr.getInfo().setCurrentLoc("out");
                System.out.println(nodePtr.getInfo());
                totalPrice = totalPrice + nodePtr.getInfo().getPrice();
            }
            nodePtr = nodePtr.getNext();
        }
        return totalPrice;
    }

    /**
     * Goes through the store's inventory and prints all items that have the
     *     given rfidTagNumber.
     * @param rfidNum the rfidTag of the info.
     * O(N) as it goes through the entire list to find items with that RFID.
     */
    public void printbyRFID(String rfidNum) throws IllegalArgumentException {
        System.out.println(
        "\n                               Original        Current" +
        "\nItem Name         RFID         Location        Location     Price" +
        "\n---------       ---------     ---------        ---------   ------");
        int counter = 0;
        ItemInfoNode nodePtr = head;
        boolean isHex = rfidNum.matches("^[0-9a-fA-F]+$");
        if (rfidNum.length() == 9 || isHex) {
        }
        else {
            throw new IllegalArgumentException("Inproper rfidTag.");
        }
        while (nodePtr != null) {
            if(nodePtr.getInfo().getrfidTagNumber().equalsIgnoreCase(rfidNum)) {
                System.out.println(nodePtr.getInfo());
                counter++;
            }
            nodePtr = nodePtr.getNext();
        }
        if (counter == 0) {
            System.out.println("There were no items with that rfidTag.");
        }
    }

}