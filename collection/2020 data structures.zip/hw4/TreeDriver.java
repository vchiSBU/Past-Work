// Vincent Chi, 112811026, vincent.chi@stonybrook.edu, hw#4, R30 Section 1
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

/**
* TreeDriver class is the UI for this homework.
*/
public class TreeDriver {

    /**
     * requests string input from user
     * @param scan the input
     * @param prompt the request
     * @return input
     */
    private static String reqInput(Scanner scan, String prompt){
        System.out.print(prompt);
        String answer = scan.next();
        return answer;
    }

    public static void main(String[] args) throws IllegalArgumentException {
        Scanner scan = new Scanner(System.in);
        System.out.println("\n Homework 4 ");
        Tree userTree = new Tree();

        while (true) {
            System.out.println("\nL - Load a Tree.\n"
            + "H - Begin a Help Session.\n"
            + "T - Traverse the Tree in preorder.\n"
            + "Q - Quit\n");

            System.out.print("Choice> ");
            String input = scan.next();
            System.out.println();

            if (input.equalsIgnoreCase("L")){
                String fileName = reqInput(scan, "Enter the file name> ");
                try {
                    File file = new File(fileName);
                    Scanner fileScan = new Scanner(file);
                    String rootLabel = fileScan.nextLine();
                    // System.out.println(rootLabel); //Test
                    String rootPrompt = fileScan.nextLine();
                    // System.out.println(rootPrompt); //Test
                    String rootMessage = fileScan.nextLine();
                    // System.out.println(rootMessage); //Test
                    userTree.setRoot(rootMessage, rootPrompt, rootLabel);
    
                    while (fileScan.hasNextLine()) {
                        String info = fileScan.nextLine();
                        String parentLabel = info.substring(0,
                                             info.length()-2);
                        int numOfChildren = Integer.valueOf(info.substring(
                                            info.length() - 1, info.length()));
                        if (numOfChildren > 3) {
                            System.out.println("Not valid tree");
                            break;
                        }
                        for (int i=0; i<numOfChildren; i++) {
                            String label = "";
                            String message = "";
                            String prompt = "";
                            for (int counter = 0; counter < 3; counter++) {
                                if (counter == 0) {
                                    label = fileScan.nextLine();
                                }
                                else if (counter == 1) {
                                    message = fileScan.nextLine();
                                }
                                else {
                                    prompt = fileScan.nextLine();
                                }
                            }
                            userTree.addNode(label,message,prompt,parentLabel);
                        }
                    }
                    fileScan.close();
                } catch (FileNotFoundException e) {
                    System.out.println("File does not exist.");
                    break;
                }

            } else if (input.equalsIgnoreCase("H")){ 
                userTree.beginSession();
            
            } else if (input.equalsIgnoreCase("T")){ 
                userTree.preOrder();
            
            } else if (input.equalsIgnoreCase("Q")){ 
                break;

            } else {
                System.out.println("Please input a valid option.");
            }
        }
    }
}