// Vincent Chi, 112811026, vincent.chi@stonybrook.edu, hw#4, R30 Section 1
/**
* TreeNode class holds information in each Tree Node.
*/
public class TreeNode {
    private TreeNode Left;
    private TreeNode Middle;
    private TreeNode Right;
    private TreeNode parentNode;
    private String label;
    private String message;
    private String prompt;

    /**
     * Constructor for this tree.
     * @param name is the label to set.
     * @param msg is the message to set.
     * @param prmpt is the prompt to set.
     */
    public TreeNode(String name, String msg, String prmpt) {
        label = name;
        message = msg;
        prompt = prmpt;
    }

    /**
     * Extra credit to backtrack in session.
     */
    public TreeNode getParentNode() {
        return parentNode;
    }

    public void setParentNode(TreeNode parent) {
        parentNode = parent;
    }

    /**
     * Getters and setters for all private variables.
     */
    public TreeNode getLeft() {
        return Left;
    }

    public TreeNode getMiddle() {
        return Middle;
    }

    public TreeNode getRight() {
        return Right;
    }

    public String getLabel() {
        return label;
    }

    public String getMessage() {
        return message;
    }

    public String getPrompt() {
        return prompt;
    }

    public void setLeft(TreeNode toSet) {
        Left = toSet;
    }

    public void setMiddle(TreeNode toSet) {
        Middle = toSet;
    }

    public void setRight(TreeNode toSet) {
        Right = toSet;
    }

    public void setLabel(String toSet) {
        label = toSet;
    }

    public void setMessage(String toSet) {
        message = toSet;
    }

    public void setPrompt(String toSet) {
        prompt = toSet;
    }

    public String toString() {
        String toReturn = "\nLabel: " + label + "\nPrompt: " + prompt +
                          "\nMessage: " + message;
        return toReturn;
    }
}