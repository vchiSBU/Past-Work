// Vincent Chi, 112811026, vincent.chi@stonybrook.edu, hw#4, R30 Section 1
import java.util.Scanner;

/**
* Tree class holds information about this tree as well as methods
* to interact with it.
*/
public class Tree {
    private TreeNode root; // root of this tree

    /**
     * Constructor for this tree.
     */
    public Tree() {

    }

    /**
     * Sets the root with information.
     * @param prompt prompt of the node to add.
     * @param message message of the node to add.
     * @param label label of the node to add.
     */
    public void setRoot(String message, String prompt, String label) {
        root = new TreeNode(label, message, prompt);
        // System.out.println(message); //Test
        // root.setMessage(message);
        // root.setPrompt(prompt);
        // root.setLabel(label);
    }

    /**
     * Adds a node into this tree.
     * @param label label of the node to add.
     * @param prompt prompt of the node to add.
     * @param message message of the node to add.
     * @param parentLabel to find where this node belongs.
     */
    public boolean addNode(String label,
                           String prompt,
                           String message,
                           String parentLabel) {
        TreeNode toTraverse = root;
        addNodeHelper(toTraverse, label, prompt, message, parentLabel);

        return false;
    }

    /**
     * Helper to addNode.
     * @param toIterate the label to find.
     * @param label label of the node to add.
     * @param prompt prompt of the node to add.
     * @param message message of the node to add.
     * @param parentLabel to find where this node belongs.
     */
    private boolean addNodeHelper(TreeNode toIterate,
                                 String label,
                                 String prompt,
                                 String message,
                                 String parentLabel) {
        if (toIterate.getLabel().equals(parentLabel)) {
            if (toIterate.getLeft() == null) {
                toIterate.setLeft(new TreeNode(label,message,prompt));
                toIterate.getLeft().setParentNode(toIterate);
                return true;
            }
            else if (toIterate.getMiddle() == null) {
                toIterate.setMiddle(new TreeNode(label,message,prompt));
                toIterate.getMiddle().setParentNode(toIterate);
                return true;
            }
            else if (toIterate.getRight() == null) {
                toIterate.setRight(new TreeNode(label,message,prompt));
                toIterate.getRight().setParentNode(toIterate);
                return true;
            }
            else {
                return false;
            }
        }
        else {
            boolean isLeftTrue = false;
            boolean isMiddleTrue = false;
            boolean isRightTrue = false;
            if (toIterate.getLeft() != null) {
                isLeftTrue = addNodeHelper(toIterate.getLeft(),
                                           label,
                                           prompt,
                                           message,
                                           parentLabel);
            }
            if (toIterate.getMiddle() != null) {
                isMiddleTrue = addNodeHelper(toIterate.getMiddle(),
                                             label,
                                             prompt,
                                             message,
                                             parentLabel);
            }
            if (toIterate.getRight() != null) {
                isRightTrue = addNodeHelper(toIterate.getRight(),
                                            label,
                                            prompt,
                                            message,
                                            parentLabel);
            }
            if (isLeftTrue || isMiddleTrue || isRightTrue) {
                return true;
            }
            else {
                return false;
            }
        }
    }

    /**
     * Traverses tree until it gets to the Node with a specific label.
     * @param label the label to find.
     */
    public TreeNode getNodeReference(String label) {
        TreeNode toTraverse = root;
        return getNodeReference(toTraverse, label);
    }

    /**
     * Helper to getNodeReference.
     * @param label the label to find.
     * @param toIterate Tree Node to iterate.
     */
    private TreeNode getNodeReference(TreeNode toIterate, String label) {
        if (toIterate.getLabel().equals(label)) {
            return toIterate;
        }
        else {
            if (toIterate.getLeft() != null) {
                return getNodeReference(toIterate.getLeft(), label);
            }
            if (toIterate.getLeft() != null) {
                return getNodeReference(toIterate.getMiddle(), label);
            }
            if (toIterate.getLeft() != null) {
                return getNodeReference(toIterate.getRight(), label);
            }
            else {
                return null;
            }
        }
    }

    /**
     * Traverses the tree in preorder. Prints the contents to the screen.
     */
    public void preOrder() {
        if (root != null) {
            helper(root);
        }
        else {
            System.out.println("Tree is empty!");
        }
    }

    /**
     * Helper method for preorder traversal.
     * @param node the node to recurse through.
     */
    private void helper(TreeNode node) {
        System.out.println(node);

        if (node.getMiddle() != null) {
            helper(node.getMiddle());
        }
        if (node.getLeft() != null) {
            helper(node.getLeft());
        }
        if (node.getRight() != null) {
            helper(node.getRight());
        }            
    }

    /**
     * requests String input from user
     * @param scan the input
     * @param prompt the request
     * @return int
     */
    private static String reqInput(Scanner scan, String prompt){
        System.out.print(prompt);
        String answer = scan.next();
        return answer;
    }

    /**
     * This method will be used to start the question and answer session.
     */
    public void beginSession() {
        Scanner scan = new Scanner(System.in);
        TreeNode toTraverse = root;
        while (toTraverse != null) {
            System.out.println(toTraverse.getMessage());
            if (toTraverse.getLeft() != null) {
                System.out.println("\n1. " + toTraverse.getLeft().getPrompt());
            }
            if (toTraverse.getMiddle() != null) {
                System.out.println("2. " + toTraverse.getMiddle().getPrompt());
            }
            if (toTraverse.getRight() != null) {
                System.out.println("3. " + toTraverse.getRight().getPrompt());
            }
            System.out.println("B. Go back to previous option\n" +
                               "0. Exit Session.");
            String answer = reqInput(scan, "Choice> ");
            if (answer.equals("1")) {
                toTraverse = toTraverse.getLeft();
            }
            else if (answer.equals("2")) {
                toTraverse = toTraverse.getMiddle();
            }
            else if (answer.equals("3")) {
                toTraverse = toTraverse.getRight();
            }
            else if (answer.equals("0")) {
                break;
            }
            else if (answer.equalsIgnoreCase("B")) {
                if (toTraverse == root) {
                    System.out.println("You're already at the root!");
                }
                else {
                    toTraverse = toTraverse.getParentNode();
                }
            }
            else {
                System.out.println("PLEASE SELECT VALID INPUT.");
            }
            
        }
    }
}