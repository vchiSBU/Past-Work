// Vincent Chi, 112811026, vincent.chi@stonybrook.edu, hw#1, R30

/**
* The SongRecord class is an object class that holds information about songs.
**/
public class SongRecord extends Exception{
    
    private String title; // the title of the song.
    private String artist; // the artist of the song.
    private int minutes; // the minutes value of a song.
    private int seconds; // the seconds value of a song.

    /**
     * SongRecord constructor.
     */
    public SongRecord(){

    }

    /**
     * constructor for SongRecord with parameters
     * @param songTitle the title of the song.
     * @param songArtist the artist of the song.
     * @param songMinutes the minutes value of a song.
     * @param songSeconds the seconds value of a song.
     */
    public SongRecord (String songTitle,
                       String songArtist,
                       int songMinutes,
                       int songSeconds)
                       throws IllegalArgumentException{
        title = songTitle;
        artist = songArtist;
        if (songMinutes < 0 || songSeconds < 0 || songSeconds > 59) {
            throw new IllegalArgumentException("Please check your minutes and seconds.");
        }
        minutes = songMinutes;
        seconds = songSeconds;
    }

    /**
     * @return the title
     */
    public String getTitle() {
        return title;
    }

    /**
     * @param title the title to set
     */
    public void setTitle(String title) {
        this.title = title;
    }

    /**
     * @return the artist
     */
    public String getArtist() {
        return artist;
    }

    /**
     * @param artist the artist to set
     */
    public void setArtist(String artist) {
        this.artist = artist;
    }

    /**
     * @return the minutes
     */
    public int getMinutes() {
        return minutes;
    }

    /**
     * @param minutes the minutes to set
     */
    public void setMinutes(int minutes) {
        this.minutes = minutes;
    }

    /**
     * @return the seconds
     */
    public int getSeconds() {
        return seconds;
    }

    /**
     * @param seconds the seconds to set
     */
    public void setSeconds(int seconds) {
        this.seconds = seconds;
    }

    /**
     * This method pads strings so that they are aligned.
     * @param s the string that needs padding.
     * @param n the spaces needed to align.
     * @return the padded string.
     */
    public static String padRight(String s, int n) {
        return String.format("%-" + n + "s", s);
    }

    /**
     * This method creates a neatly displayed toString of this SongRecord.
     */
    public String toString(){
        String stringToReturn;
        if (this.seconds < 10) {
            stringToReturn = padRight("", 9) +
                             padRight(this.title, 16) +
                             padRight(this.artist, 16) +
                             String.valueOf(this.minutes) + ":0" +
                             String.valueOf(this.seconds);
        }
        else {
            stringToReturn = padRight("", 9) +
                             padRight(this.title, 16) +
                             padRight(this.artist, 16) +
                             String.valueOf(this.minutes) + ":" +
                             String.valueOf(this.seconds);
        }
        return stringToReturn;
    }

    // public SongRecord clone(){
    //     return new Song(title, artist, minutes, seconds);
    // }

}