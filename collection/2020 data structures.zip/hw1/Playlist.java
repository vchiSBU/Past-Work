// Vincent Chi, 112811026, vincent.chi@stonybrook.edu, hw#1, R30

/**
* The Playlist class implements an array data structure for SongRecords.
**/

public class Playlist{
    private final int MAXIMUM = 50; // data size specified by homework.
    public SongRecord[] data; // the array for SongRecords.
    private int size;
    private String name;

    /**
     * Playlist constructor.
     * This Playlist has been initialized to an empty array of SongRecords.
     */
    public Playlist(){
        data = new SongRecord[MAXIMUM];
    }

    /**
     * Clones playlist.
     * @return a hard copy of this playlist.
     */
    public Object clone() {
        Playlist playlistToReturn = new Playlist();
        for (int i = 0; i < this.size(); i++) {
            playlistToReturn.data[i] = new SongRecord(this.data[i].getTitle(),
                                                      this.data[i].getArtist(),
                                                      this.data[i].getMinutes(),
                                                      this.data[i].getSeconds());
        }
        return playlistToReturn;
    }

    /**
     * This method tests whether a passed playlist is equal to this playlist.
     * @param obj the passed playlist to test equality.
     * @return truth value for equality.
     */
    public boolean equals(Object obj) {
        boolean toReturn = true;
        if (obj instanceof Playlist) {
            Playlist obj2 = (Playlist)obj;
            for (int i = 0; i < this.size(); i++) {
                if (this.data[i].getTitle().equals(obj2.data[i].getTitle()) &&
                    this.data[i].getArtist().equals(obj2.data[i].getArtist()) &&
                    this.data[i].getMinutes() == obj2.data[i].getMinutes() &&
                    this.data[i].getSeconds() == obj2.data[i].getSeconds()) {
                    continue;
                }
                else {
                    toReturn = false;
                    break;
                }
            }
        }
        else {
            return false;
        }
        return toReturn;
    }

    /**
     * This method determines the number of songs in this playlist.
     * @return integer value for the size of the playlist.
     */
    public int size() {
        return size;
    }

    /**
     * This method adds a song at a specified position in this playlist.
     * @param song the song to be added.
     * @param position the position where the song is added.
     */
    public void addSong(SongRecord song, int position) throws IllegalArgumentException, FullPlaylistException{
        try {
            if (this.size() == MAXIMUM) {
                throw new FullPlaylistException();
            }
        }
        catch (FullPlaylistException e) {
            System.out.println("Full Playlist Exception: Your playlist is full!");
        }
        
        if (position < 0 || position > this.size()) {
            throw new IllegalArgumentException("The song position requested is out of bounds.");
        }
        else {
            if (position + 1 == MAXIMUM) {
                data[position] = song;
            }
            else {
                SongRecord temporaryHolder1 = song;
                SongRecord temporaryHolder2 = data[position];
            
                for (int i = position; i < MAXIMUM - 1; i++) {
                    data[i] = temporaryHolder1;
                    temporaryHolder1 = temporaryHolder2;
                    temporaryHolder2 = data[i+1];
                }
            }
        }
        this.size++;
        // else {
        //     SongRecord[] result = new SongRecord[MAXIMUM];
        //     for (int i = 0; i < position; i++) {
        //         result[i] = data[i];
        //     }
        //     result[position] = song;
        //     for (int i = position + 1; i < data.length; i++) {
        //         result[i] = data[i - 1];
        //     }
        //     data = result;

        // }
    }

    /**
     * This method removes a song from the playlist at a specified position.
     * @param position the position of the song to be removed.
     */
    public void removeSong(int position) throws IllegalArgumentException {
        if (position < 0 || position > this.size()) {
            throw new IllegalArgumentException("The provided position cannot be accessed.");
        }
        if (data[position] != null) {
            size--;
        }
        if (position == MAXIMUM - 1) {
            data[MAXIMUM - 1] = null;
        }
        else if(data[MAXIMUM - 1] != null) {
            SongRecord temp = data[MAXIMUM - 1];
            data[MAXIMUM - 1] = null;
            System.arraycopy(this.data, position + 1, this.data, position, this.data.length - 1 - position);
            data[MAXIMUM - 2] = temp;
            position--;
        }
        else {
            System.arraycopy(this.data, position + 1, this.data, position, this.data.length - 1 - position);
        }


        // position--;
        // SongRecord temporaryHolder1 = data[position + 1];
        // for (int i = position; i < MAXIMUM-1; i++) {
        //     data[i] = temporaryHolder1;
        //     temporaryHolder1 = data[i+1];
        // }
    }

    /**
     * This method isolates a song at a specified position.
     * @param position the position of the song to be returned.
     * @return the song at the specified position.
     */
    public SongRecord getSong(int position) throws IllegalArgumentException {
        if (position < 0 || position > size()) {
            throw new IllegalArgumentException("The provided position cannot be accessed.");
        }
        position--;
        return data[position];
    }

    /**
     * This method prints all the songs in this playlist.
     */
    public void printAllSongs() {
        System.out.println(toString());
    }

    /**
     * This method finds all the songs by an artist.
     * @param originalList the playlist to look for songs by artist.
     * @param artist the desired artist of the songs.
     * @return a playlist with all the songs by that artist.
     */
    public static Playlist getSongsByArtist(Playlist originalList, String artist) {
        Playlist byArtist = new Playlist();
        int positionCounter = 0;
        for (int i = 0; i < originalList.size(); i++) {
            if (originalList.data[i].getArtist().equals(artist)) {
                byArtist.data[positionCounter] = originalList.data[i];
                byArtist.size++;
                positionCounter++;
            }
        }
        return byArtist;
    }

    /**
     * This method creates a neatly displayed toString of this playlist.
     */
    public String toString() {
        String listOfSongs = "Song#     Title           Artist          Length\n" +
                             "------------------------------------------------\n";
        for (int i = 1; i <= this.size(); i++) {
            listOfSongs = listOfSongs + String.valueOf(i) + data[i-1] + "\n";
        }
        return listOfSongs;
    }
    public String getName() {
        return name;
    }

    public void setName(String toSet) {
        name = toSet;
    }

}