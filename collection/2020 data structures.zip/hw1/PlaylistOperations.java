// Vincent Chi, 112811026, vincent.chi@stonybrook.edu, hw#1, R30

/**
 * PlaylistOperations
 */
import java.util.Scanner;

public class PlaylistOperations {

    /**
     * requests string input from user
     * @param scan the input
     * @param prompt the request
     * @return input
     */
    private static String reqInput(Scanner scan, String prompt){
        System.out.print(prompt);
        String answer = scan.next();
        return answer;
    }

    /**
     * requests integer input from user
     * @param scan the input
     * @param prompt the request
     * @return int
     */
    private static int reqInt(Scanner scan, String prompt){
        System.out.print(prompt);
        int answer = scan.nextInt();
        return answer;
    }
    public static void main(String[] args) throws FullPlaylistException {
        Playlist newlist = new Playlist();
        Scanner scan = new Scanner(System.in);
        System.out.println("\n Homework 1 \n");

        while (true) {

            String menu = "A) Add Song\n"
            + "B) Print Songs by Artist\n"
            + "G) Get Song\n"
            + "R) Remove Song \n"
            + "P) Print All Songs\n"
            + "S) Size\n"
            + "Q) Quit\n\n";
            System.out.println(menu);
            System.out.print("Enter an option: ");
            String input = scan.next();
            System.out.println();

            if (input.equalsIgnoreCase("A")){
                String songTitle = reqInput(scan, "Enter the song title: ");
                String songArtist = reqInput(scan, "Enter the song artist: ");
                int songMinutes = reqInt(scan, "Enter the song length (minutes): ");
                int songSeconds = reqInt(scan, "Enter the song length (seconds): ");
                int songPosition = reqInt(scan, "Enter the position: ");
                SongRecord song = new SongRecord(songTitle, songArtist, songMinutes, songSeconds);
                newlist.addSong(song, songPosition - 1);
                System.out.println("Song successfully added!\n");

            } else if (input.equalsIgnoreCase("B")){ 
                String artistFind = reqInput(scan, "Enter artist(s) name: ");
                Playlist byArtist = newlist.getSongsByArtist(newlist, artistFind);
                byArtist.printAllSongs();
            
            } else if (input.equalsIgnoreCase("G")){ 
                int artistFind = reqInt(scan, "Enter position: ");
                Playlist singleSong = new Playlist();
                singleSong.addSong(newlist.getSong(artistFind), 0);
                System.out.println(singleSong);

            } else if (input.equalsIgnoreCase("R")){ 
                int removePosition = reqInt(scan, "Enter position: ");
                newlist.removeSong(removePosition - 1);
                System.out.println("A song has been removed at position " + String.valueOf(removePosition) + "!\n");
            
            } else if (input.equalsIgnoreCase("S")){ 
                System.out.println("\nThere are " + String.valueOf(newlist.size()) + " song(s) in the current playlist.\n");

            } else if (input.equalsIgnoreCase("P")){ 
                newlist.printAllSongs();

            } else if (input.equalsIgnoreCase("Q")){
                System.out.println("\nProgram terminated.\n");
                break;

            } else {
                System.out.println("\nInvalid command.\n");
            }

        }
    }
}
