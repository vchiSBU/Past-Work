// Vincent Chi, 112811026, vincent.chi@stonybrook.edu, hw#1, R30

/**
* The FullPlaylistException an exception for when the playlist is full.
**/
public class FullPlaylistException extends Exception {
    public static final long serialVersionUID = 42L;

    // Parameterless Constructor
    public FullPlaylistException() {}

    /* Constructor that accepts a message
     * @param message to be sent.
    */
    public FullPlaylistException(String message)
    {
       super(message);
    }

}