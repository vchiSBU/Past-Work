// Vincent Chi, 112811026, vincent.chi@stonybrook.edu, hw#3, R30 Section 1

import java.util.Vector;

/**
 * RequestQueue
 * Holds a queue of Requests.
 */

public class RequestQueue extends Vector<Request> {

    /**
     * Satisfying serialVersionUID.
     */
    private static final long serialVersionUID = 1L;

    /**
     * Constructor to make an empty RequestQueue.
     */
    public RequestQueue() {

    }

    /**
     * Enqueues a Request to this RequestQueue.
     * @param toEnqueue Request to be enqueued.
     * @return boolean for if enqueue was successful.
     */
    public boolean enqueue(Request toEnqueue) {
        return this.add(toEnqueue);
    }

    /**
     * Dequeues a Request from this RequestQueue.
     * @return the Request dequeued.
     */
    public Request dequeue() {
        return this.remove(0);
    }
    
    /**
     * size() and isEmpty() are already supplied through Vector implementation.
     */
}