// Vincent Chi, 112811026, vincent.chi@stonybrook.edu, hw#3, R30 Section 1

/**
 * Request
 * Holds information about Elevator requests.
 */

public class Request {
    private int sourceFloor;
    private int destinationFloor;
    private int timeEntered;

    public Request() {

    }

    /**
     * Request constructor.
     * sourceFloor and destinationFloor will be randomly generated.
     * The random values must be between 1 and the number of floors.
     * @param numberOfFloors the number of floors in the building.
     */
    public Request(int numberOfFloors) {
        sourceFloor = (int)Math.random()*numberOfFloors + 1;
        destinationFloor = (int)Math.random()*numberOfFloors + 1;
    }

    /**
     * Getter and mutator methods for private variables:
     */
    public int getSource() {
        return sourceFloor;
    }

    public void setSource(int toSet) {
        sourceFloor = toSet;
    }

    public int getDest() {
        return destinationFloor;
    }

    public void setDest(int toSet) {
        destinationFloor = toSet;
    }

    public int getTime() {
        return timeEntered;
    }

    public void setTime(int toSet) {
        timeEntered = toSet;
    }
}