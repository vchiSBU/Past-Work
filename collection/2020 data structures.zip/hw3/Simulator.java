// Vincent Chi, 112811026, vincent.chi@stonybrook.edu, hw#3, R30 Section 1

import java.util.*;

/**
 * Simulator
 * The simulator class carries out the simulation.
 */

public class Simulator {

    /**
     * Simulates a building with elevators and random requests.
     * @param probability the desired probability of random requests.
     * @param numOfFloors the number of floors in the building.
     * @param numOfElevators the number of elevators in the building.
     * @param timeLength the time length to simulate.
     */
    public static void simulate(double probability,
                                int numOfFloors,
                                int numOfElevators,
                                int timeLength) {
        BooleanSource chance = new BooleanSource(probability);
        RequestQueue toDo = new RequestQueue();
        Set<Elevator> elevators = new HashSet<Elevator>();

        int totalRequests = 0;
        int totalWaitTime = 0;

        for (int i = 0; i < numOfElevators; i++) {
            elevators.add(new Elevator());
        }

        for (int i = 0; i < timeLength; i++) {
            if (chance.requestArrived()) {
                totalRequests++;
                Iterator<Elevator> toIterate = elevators.iterator();
                Request newRequest = new Request(numOfFloors);
                
                newRequest.setTime(i);
                toDo.enqueue(newRequest);

                while (toIterate.hasNext()) {
                    Elevator temp = toIterate.next();
                    if (temp.getElevator() == temp.IDLE) {
                        int waitTime = Math.abs(
                            newRequest.getSource() - temp.getCurrent());
                        Request toDoRequest = toDo.dequeue();
                        if (temp.getCurrent() == toDoRequest.getDest()) {
                            
                        }
                        else if (temp.getCurrent() == toDoRequest.getSource()) {
                            temp.setRequest(toDoRequest);
                            temp.setElevator(temp.TO_DESTINATION);
                        }
                        else {
                            temp.setRequest(toDoRequest);
                            temp.setElevator(temp.TO_SOURCE);
                            totalWaitTime = totalWaitTime + waitTime;
                        }
                        if (toDo.isEmpty()) {
                            break;
                        }
                        else {

                        }
                    }
                }
            }
            Iterator<Elevator> toIterate = elevators.iterator();
            while (toIterate.hasNext()) {
                Elevator temp = toIterate.next();
                if (temp.getElevator() == temp.TO_SOURCE) {
                    temp.setElevator(moveToSource(temp));
                }
                else if (temp.getElevator() == temp.TO_DESTINATION) {
                    temp.setElevator(moveToDest(temp));
                }
                else {
                    if (toDo.isEmpty()) {

                    }
                    else {
                        temp.setRequest(toDo.dequeue());
                        temp.setElevator(temp.TO_SOURCE);
                    }
                }
            }

        }

        System.out.println("Total Wait Time: " + totalWaitTime);
        System.out.println("Total Requests: " + totalRequests);
        System.out.println("Average Wait Time: " + totalWaitTime/totalRequests);
        
        
    }

    /**
     * Moves an elevator closer to the source of a request.
     * @param toMove the Elevator to move.
     */
    private static int moveToSource(Elevator toMove) {
        if (toMove.getCurrent() < toMove.getRequest().getSource()) {
            toMove.setCurrent(toMove.getCurrent() + 1);
            return toMove.TO_SOURCE;
        }
        else if (toMove.getCurrent() > toMove.getRequest().getSource()){
            toMove.setCurrent(toMove.getCurrent() - 1);
            return toMove.TO_SOURCE;
        }
        else {
            toMove.setElevator(2);
            return toMove.TO_DESTINATION;
        }
    }

    /**
     * Moves an elevator closer to the destination of a request.
     * @param toMove the Elevator to move.
     */
    private static int moveToDest(Elevator toMove) {
        if (toMove.getCurrent() < toMove.getRequest().getDest()) {
            toMove.setCurrent(toMove.getCurrent() + 1);
            return toMove.TO_DESTINATION;
        }
        else if (toMove.getCurrent() > toMove.getRequest().getDest()){
            toMove.setCurrent(toMove.getCurrent() - 1);
            return toMove.TO_DESTINATION;
        }
        else {
            toMove.setElevator(2);
            return toMove.IDLE;
        }
    }
}