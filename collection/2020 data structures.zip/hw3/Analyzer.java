// Vincent Chi, 112811026, vincent.chi@stonybrook.edu, hw#3, R30 Section 1

/**
 * Analyzer
 * The UI for this homework.
 */
import java.util.Scanner;

public class Analyzer {

    /**
     * requests string input from user
     * @param scan the input
     * @param prompt the request
     * @return input
     */
    private static String reqInput(Scanner scan, String prompt){
        System.out.print(prompt);
        String answer = scan.next();
        return answer;
    }

    /**
     * requests integer input from user
     * @param scan the input
     * @param prompt the request
     * @return int
     */
    private static int reqInt(Scanner scan, String prompt){
        System.out.print(prompt);
        int answer = scan.nextInt();
        return answer;
    }
    
    /**
     * requests double input from user
     * @param scan the input
     * @param prompt the request
     * @return double
     */
    private static double doubInp(Scanner scan, String prompt){
        System.out.print(prompt);
        double answer = scan.nextDouble();
        return answer;
    }

    public static void main(String[] args) throws IllegalArgumentException {
        Scanner scan = new Scanner(System.in);
        System.out.println("\n Homework 3 " +
                           "\n Welcome to the Elevator simulator!");

        double probability = doubInp(scan, "Please enter the probability " +
                                           "of arrival for Requests: ");
        if (probability > 1.0 || probability < 0.0) {
            throw new IllegalArgumentException("Not a valid probability.");
        }
        int numOfFloors = reqInt(scan, "Please enter the number of floors: ");
        if (numOfFloors < 1) {
            throw new IllegalArgumentException("A building can have at least " +
                                               "1 whole floor.");
        }
        int numOfElev = reqInt(scan, "Please enter the number of elevators: ");
        if (numOfElev < 0) {
            throw new IllegalArgumentException("This simulator requires " +
                                               "at least 1 elevator.");
        }
        int time = reqInt(scan, "Please enter the length of the simulation " +
                                "(in time units): ");
        if (time < 0) {
            throw new IllegalArgumentException("Invalid time input.");
        }

        Simulator.simulate(probability, numOfFloors, numOfElev, time);

    }
}