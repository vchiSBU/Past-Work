// Vincent Chi, 112811026, vincent.chi@stonybrook.edu, hw#3, R30 Section 1

/**
 * Elevator
 * Elevator class holds information about the state of an elevator.
 */

public class Elevator {
    private int currentFloor;
    private int elevatorState;
    public final int IDLE = 0;
    public final int TO_SOURCE = 1;
    public final int TO_DESTINATION = 2;
    private Request request;

    /**
     * Elevator constructor.
     * Sets request to null, elevatorState to IDLE, and currentFloor to 1.
     */
    public Elevator() {
        request = null;
        elevatorState = IDLE;
        currentFloor = 1;
    }

    /**
     * Getter and mutator methods for private variables:
     */
    public int getCurrent() {
        return currentFloor;
    }

    public void setCurrent(int toSet) {
        currentFloor = toSet;
    }

    public int getElevator() {
        return elevatorState;
    }

    public void setElevator(int toSet) {
        elevatorState = toSet;
    }

    public Request getRequest() {
        return request;
    }

    public void setRequest(Request toSet) {
        request = toSet;
    }
}