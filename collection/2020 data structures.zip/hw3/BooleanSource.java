// Vincent Chi, 112811026, vincent.chi@stonybrook.edu, hw#3, R30 Section 1

/**
 * BooleanSource
 * The probability for new Requests.
 */

public class BooleanSource {
    private double probability;

    /**
     * BooleanSource constructor.
     * Accepts a double as a parameter as the value of this member variable.
     * @param toSet the desired probability.
     */
    public BooleanSource(double toSet) throws IllegalArgumentException {
        if (toSet < 0.0 || toSet > 1.0) {
            throw new IllegalArgumentException();
        }
        probability = toSet;
    }

    /**
     * Returns true a percentage of the time equal to probability.
     * @return the boolean value.
     */
    public boolean requestArrived() {
        return (probability > Math.random());
    }
}